import java.util.Scanner;

//Name: Samia Tabassum, Julie Ramires, Jimena Pulido, Chase Avilucea

public class Main {
    public static void main(String[] args) {
        TicTacToe game = new TicTacToe();
        game.play();
    }
}

class TicTacToe {

    private static final int BOARDSIZE = 3;

    private final char[][] board = {//Spaces for characters
        {' ', ' ', ' '},
        {' ', ' ', ' '},
        {' ', ' ', ' '}
    };

    private boolean firstPlayer = true;
    private boolean gameOver = false;

    enum Status {
        WIN,
        DRAW,
        CONTINUE
    }

    public void play() {
        Scanner input = new Scanner(System.in);

        printBoard();

        while (!gameOver) {//When the game isn't over
            char currentPlayer;

            if (firstPlayer) {
                currentPlayer = 'X';//Makes X the first player
                printStatus(1);
            } else {
                currentPlayer = '0';//Goes to 0 when player switches
                printStatus(0);
            }

            System.out.print("Pick a row (0, 1, or 2): ");

            if (!input.hasNextInt()) {//Receives input for row and checks if input is an integer
                System.out.println("Please enter a number.");
                input.next();
                continue;
            }

            int row = input.nextInt();

            System.out.print("Pick a column (0, 1, or 2): ");

            if (!input.hasNextInt()) {//Receives input for column and checks if input is an integer
                System.out.println("Please enter a number.");
                input.next();
                continue;
            }

            int column = input.nextInt();

            if (!validMove(row, column)) {//checks for invalid move if there's an attempt to place on filled position
                System.out.println(
                    "Invalid move! Choose an empty position from 0 to 2."
                );
                continue;
            }

            board[row][column] = currentPlayer;
            printBoard();

            Status status = gameStatus();

            if (status == Status.WIN) {//Prints who the winner is 
                gameOver = true;
                System.out.println("Player " + currentPlayer + " wins!");
            } else if (status == Status.DRAW) {//Handles a draw
                gameOver = true;
                System.out.println("Draw!");
            } else {
                firstPlayer = !firstPlayer;//switches player and continues
            }
        }

        input.close();
    }

    private void printStatus(int player) {
        if (player == 1) {
            System.out.println("Player X's turn");
        } else {
            System.out.println("Player 0's turn");
        }
    }

    private Status gameStatus() {//Accounts for all scenarios such as win, draw, continue
        
        for (int row = 0; row < BOARDSIZE; row++) {//checking rows
            if (board[row][0] != ' '
                    && board[row][0] == board[row][1]
                    && board[row][1] == board[row][2]) {
                return Status.WIN;
            }
        }

    
        for (int column = 0; column <BOARDSIZE; column++) {//checking columns 
            if (board[0][column] != ' '
                    && board[0][column] == board[1][column]
                    && board[1][column] == board[2][column]) {
                return Status.WIN;
            }
        }

        if (board[0][0] != ' '
                && board[0][0] == board[1][1]
                && board[1][1] == board[2][2]) {//Checks for diagonal 
            return Status.WIN;
        }

        if (board[0][2] != ' '
                && board[0][2] == board[1][1]
                && board[1][1] == board[2][0]) {//Checks for other diagonal
            return Status.WIN;
        }


        for (int row = 0; row < BOARDSIZE; row++) {
            for (int column = 0; column < BOARDSIZE; column++) {
                if (board[row][column] == ' ') {
                    return Status.CONTINUE;
                }
            }
        }

        return Status.DRAW;
    }

    public void printBoard() {//Prints the appearance of the board
        System.out.println("_________________________");

        for (int row = 0; row < BOARDSIZE; row++) {
            System.out.print("|");

            for (int column = 0; column < BOARDSIZE; column++) {//prints columns for each row
                printSymbol(column, board[row][column]);
            }

            System.out.println();
            System.out.println("|_______|_______|_______|");
        }
    }

    private void printSymbol(int column, char value) { //prints out the symbol
        System.out.printf("   %c   |", value);
    }

    private boolean validMove(int row, int column) //Checks to see if the move is valid
    {
        if (row < 0 || row >= BOARDSIZE
                || column < 0 || column >= BOARDSIZE) {
            return false;
        }

        return board[row][column] == ' ';
    }
}